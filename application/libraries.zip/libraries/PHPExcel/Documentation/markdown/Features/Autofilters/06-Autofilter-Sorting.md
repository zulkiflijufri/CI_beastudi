# PHPExcel AutoFilter Reference 


## AutoFilter Sorting

In MS Excel, Autofiltering also allows the rows to be sorted. This feature is ***not*** supported by PHPExcel.

